<?php
$servername = "db";
$username   = "root";
$password   = "verysecret";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  $connected = false;
} else {
  $connected = true;
}

$quotes = Array(
  "Lorem ipsum dolor sit amet",
  "Ein zwei drei käse wurst und ei",
  "Hello world"
);

$quote = $quotes[array_rand($quotes)];

?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8"/>
    <style type="text/css">
      body { background-color: rgb(215, 52, 52); color: white; }
      body.connected { background-color: rgb(94, 171, 50); }
      h1 { font-family: Helvetica, Arial, sans-serif; margin-top: 100px;
      text-align: center; }
      p { text-align: center; }
    </style>
  </head>
  <body class="<?= $connected ? 'connected' : '' ?>">
  <?php if (!$connected) { ?>
    <h1>Sidan är nere för underhåll</h1>
    <p>Kunde inte ansluta till databasen. Modermodemet, själva hjärtat i
    hårddisken, fungerar inte.</p>
  <?php } else { ?>
    <h1>Supergrön webbsajt</h1>
    <p><?= $quote ?></p>
  <?php } ?>
  </body>
</html>
